const BASE_URL = "https://agstest.online/public";

export default BASE_URL;

export const BaseUrl = "https://pranidaya.online/public/api";
