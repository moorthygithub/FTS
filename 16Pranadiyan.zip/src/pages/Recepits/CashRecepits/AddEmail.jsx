function AddEmail() {
  return (
    <>
      <h1>Add emails</h1>
    </>
  );
}
export default AddEmail;
