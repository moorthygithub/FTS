import React from "react";

const ExamDownload = () => {
  return <div>ExamDownload</div>;
};

export default ExamDownload;
