import React from "react";

const StudentDownload = () => {
  return <div>StudentDownload</div>;
};

export default StudentDownload;
